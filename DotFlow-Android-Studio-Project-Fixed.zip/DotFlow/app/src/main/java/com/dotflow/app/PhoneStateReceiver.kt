package com.dotflow.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager

class PhoneStateReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE)
        val label = when (state) {
            TelephonyManager.EXTRA_STATE_RINGING -> "☎  INCOMING CALL"
            TelephonyManager.EXTRA_STATE_OFFHOOK -> "☎  CALL IN PROGRESS"
            TelephonyManager.EXTRA_STATE_IDLE -> "•  DOTFLOW  •"
            else -> return
        }
        context.sendBroadcast(Intent(DotFlowService.ACTION_EVENT).setPackage(context.packageName).putExtra("message", label))
    }
}
