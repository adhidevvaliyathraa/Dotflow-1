package com.dotflow.app

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.content.Intent
import android.app.Notification
import android.os.Bundle

class DotFlowNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val extras: Bundle = sbn.notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val body = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        if (title.isBlank()) return
        val message = if (body.isBlank()) "●  $title" else "●  $title  ·  $body"
        sendBroadcast(Intent(DotFlowService.ACTION_EVENT).setPackage(packageName).putExtra("message", message.take(90)))
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        sendBroadcast(Intent(DotFlowService.ACTION_EVENT).setPackage(packageName).putExtra("message", "•  DOTFLOW  •"))
    }
}
