package com.dotflow.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
            setBackgroundColor(0xFF080808.toInt())
        }
        val title = TextView(this).apply {
            text = "DOTFLOW  •"
            textSize = 30f
            setTextColor(0xFFFFFFFF.toInt())
            letterSpacing = .12f
        }
        val subtitle = TextView(this).apply {
            text = "A Nothing-inspired live pill"
            textSize = 14f
            setTextColor(0xFFAAAAAA.toInt())
            setPadding(0, 8, 0, 24)
        }
        status = TextView(this).apply {
            text = "Setup needed"
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 8, 0, 18)
        }
        root.addView(title); root.addView(subtitle); root.addView(status)
        root.addView(actionButton("1  •  Allow display over other apps") { requestOverlay() })
        root.addView(actionButton("2  •  Enable notification access") { openNotificationAccess() })
        root.addView(actionButton("3  •  Enable call status permission") { requestPhonePermission() })
        root.addView(actionButton("START DOTFLOW") { startDotFlow() })
        root.addView(actionButton("STOP DOTFLOW") {
            stopService(Intent(this, DotFlowService::class.java))
            status.text = "DotFlow stopped"
        })
        val note = TextView(this).apply {
            text = "No Wireless debugging or ADB pairing. Grant only the permissions you want to use."
            textSize = 12f
            setTextColor(0xFF888888.toInt())
            setPadding(0, 24, 0, 0)
        }
        root.addView(note)
        setContentView(root)
    }

    private fun actionButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { action() }
    }

    private fun requestOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } else status.text = "Overlay permission already allowed"
    }

    private fun openNotificationAccess() {
        startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
    }

    private fun requestPhonePermission() {
        if (Build.VERSION.SDK_INT >= 23 &&
            checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.READ_PHONE_STATE), 42)
        } else status.text = "Call status permission already allowed"
    }

    private fun startDotFlow() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow display over other apps first", Toast.LENGTH_LONG).show()
            requestOverlay()
            return
        }
        val intent = Intent(this, DotFlowService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        status.text = "DotFlow is running • tap the pill to open this app"
    }
}
