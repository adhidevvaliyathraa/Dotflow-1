package com.dotflow.app

import android.app.*
import android.content.*
import android.graphics.PixelFormat
import android.os.*
import android.view.*
import android.widget.TextView
import androidx.core.app.NotificationCompat

class DotFlowService : Service() {
    private lateinit var windowManager: WindowManager
    private var pill: TextView? = null
    private var batteryReceiver: BroadcastReceiver? = null
    private var currentMessage = "•  DOTFLOW  •"
    private var charging = false

    private val updates = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                ACTION_EVENT -> {
                    currentMessage = intent.getStringExtra("message") ?: currentMessage
                    render()
                }
                Intent.ACTION_BATTERY_CHANGED -> {
                    val status = intent.getIntExtra("status", -1)
                    charging = status == android.os.BatteryManager.BATTERY_STATUS_CHARGING ||
                               status == android.os.BatteryManager.BATTERY_STATUS_FULL
                    if (charging) currentMessage = "⚡  CHARGING"
                    else if (currentMessage == "⚡  CHARGING") currentMessage = "•  DOTFLOW  •"
                    render()
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("DotFlow is active")
            .setContentText("Tap the floating pill to open DotFlow")
            .setOngoing(true)
            .build()
        startForeground(1001, notification)
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showPill()
        registerReceiver(updates, IntentFilter(ACTION_EVENT))
        batteryReceiver = updates
        registerReceiver(updates, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    }

    private fun showPill() {
        val view = TextView(this).apply {
            text = currentMessage
            textSize = 13f
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xFF111111.toInt())
            setPadding(42, 22, 42, 22)
            gravity = Gravity.CENTER
            setOnClickListener {
                val i = Intent(this@DotFlowService, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
            }
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(12)
        }
        try {
            windowManager.addView(view, params)
            pill = view
        } catch (_: Exception) { stopSelf() }
    }

    private fun render() { pill?.text = currentMessage }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel(CHANNEL, "DotFlow", NotificationManager.IMPORTANCE_LOW))
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onBind(intent: Intent?) = null

    override fun onDestroy() {
        try { unregisterReceiver(updates) } catch (_: Exception) {}
        try { pill?.let { windowManager.removeView(it) } } catch (_: Exception) {}
        pill = null
        super.onDestroy()
    }

    companion object {
        const val CHANNEL = "dotflow_active"
        const val ACTION_EVENT = "com.dotflow.app.EVENT"
    }
}
